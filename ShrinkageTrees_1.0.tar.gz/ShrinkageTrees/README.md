# ShrinkageTrees
Development area of R package ShrinkageTrees



``` r
# install.packages("devtools")
devtools::install_github("tijn-jacobs/ShrinkageTrees")
```



Note to self
 
How to compile the package:
* step 1: (in R) compileAttributes("/Users/tijnjacobs/Library/CloudStorage/OneDrive-VrijeUniversiteitAmsterdam/Documents/GitHub/ShrinkageTrees")
* step 2: (in terminal) R CMD build /Users/tijnjacobs/Library/CloudStorage/OneDrive-VrijeUniversiteitAmsterdam/Documents/GitHub/ShrinkageTrees
* step 3: (in R) install.packages("/Users/tijnjacobs/Library/CloudStorage/OneDrive-VrijeUniversiteitAmsterdam/Documents/GitHub/ShrinkageTrees/ShrinkageTrees_1.0.tar.gz", repos=NULL, type='source')






This package includes data derived from the pdacR package (MIT license), by Richard A. Moffitt. 