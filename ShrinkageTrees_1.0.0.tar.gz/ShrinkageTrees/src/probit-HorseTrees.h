#ifndef PROBIT_HORSETREES_H
#define PROBIT_HORSETREES_H

#include "Forest.h"
#include "TruncatedNormal.h"


#endif // PROBIT_HORSETREES_H
