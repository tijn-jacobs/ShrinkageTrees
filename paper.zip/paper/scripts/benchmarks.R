################################################################################
# Computational-speed benchmarks for the ShrinkageTrees R Journal paper (§6.5).
#
# Goal: timings table at a representative (n, p) and a scaling figure in n.
# Hardware target: 2024 MacBook Air, Apple M3, 16 GB RAM.
#
# Run from the paper/ directory:
#   Rscript scripts/benchmarks.R
#
# Outputs (per spec):
#   outputs/benchmark_table.csv       — raw rows: function, n, p, m, n_chains,
#                                       replicate, time_seconds
#   figures/benchmark_scaling.pdf     — scaling-in-n figure
#
# Side outputs (to fill in the §6.5 placeholders):
#   outputs/benchmark_meta.txt        — macOS / R / package versions, n, p,
#                                       burn-in & posterior counts
#   outputs/benchmark_table.txt       — formatted mean ± SD table for the
#                                       representative scenario (so the Rmd
#                                       can show_output() it directly)
################################################################################

suppressPackageStartupMessages({
  library(ShrinkageTrees)
  library(ggplot2)
})

setwd("~/Library/CloudStorage/OneDrive-VrijeUniversiteitAmsterdam/Documents/GitHub/ShrinkageTrees/paper/")

dir.create("figures", showWarnings = FALSE)
dir.create("outputs", showWarnings = FALSE)

# Pin BLAS / OpenMP to 1 thread so multithreaded linear algebra does not
# silently eat extra cores. ShrinkageTrees still uses parallel::mclapply for
# its native multi-chain dispatch — that uses separate processes, not BLAS
# threads, so the n_chains = 4 parallelism still lands.
Sys.setenv(OMP_NUM_THREADS      = "1",
           OPENBLAS_NUM_THREADS = "1",
           MKL_NUM_THREADS      = "1")

# ── Configuration ────────────────────────────────────────────────────────────
N_BURN   <- 50L
N_POST   <- 50L
N_CHAINS <- 4L
M_TREES  <- 200L

REP_TABLE   <- 1L                                # replications per fn at (500,100)
REP_SCALING <- 50L                                # replications per fn per n
N_GRID      <- c(100L, 250L, 500L, 1000L, 2000L) # n axis for the figure
TABLE_P <- P_FIXED     <- 1000L                              # p held fixed throughout
TABLE_N <- 100L


# Functions tested. Order matters for the figure colour mapping.
# BART::abart() does not have an n_chains argument; the BART package's
# multi-chain wrapper for abart() is BART::mc.abart(), which runs mc.cores
# independent chains in parallel (each with its own seed) via parallel::
# mcparallel. We benchmark mc.abart() with mc.cores = N_CHAINS so the
# four-chain comparison is apples-to-apples with the ShrinkageTrees fits,
# which dispatch their chains via parallel::mclapply.
FN_LEVELS <- c("SurvivalBART", "SurvivalDART", "HorseTrees", "BART::mc.abart")

# Display labels used in the figure legend. The dispatch key "BART::mc.abart"
# is precise about which function was actually called, but the paper prefers
# the shorter unqualified name "abart()" — the §6.5 prose introduces it as
# "abart() from BART".
FN_DISPLAY <- c("SurvivalBART"   = "SurvivalBART()",
                "SurvivalDART"   = "SurvivalDART()",
                "HorseTrees"     = "HorseTrees()",
                "BART::mc.abart" = "abart()")

# ── Metadata ─────────────────────────────────────────────────────────────────
have_BART <- requireNamespace("BART", quietly = TRUE)

st_ver   <- as.character(packageVersion("ShrinkageTrees"))
bart_ver <- if (have_BART) as.character(packageVersion("BART")) else "(not installed)"

# Best-effort macOS version detection.
os_string <- tryCatch({
  if (Sys.info()[["sysname"]] == "Darwin") {
    sw <- system("sw_vers", intern = TRUE)
    paste("macOS", sub("ProductVersion:\t", "",
                       grep("^ProductVersion", sw, value = TRUE)))
  } else {
    paste(Sys.info()[c("sysname", "release")], collapse = " ")
  }
}, error = function(e) Sys.info()[["sysname"]])

writeLines(c(
  paste0("OS:                ", os_string),
  paste0("R version:         ", R.version.string),
  paste0("Platform:          ", R.version$platform),
  paste0("BLAS:              ", sessionInfo()$BLAS),
  paste0("LAPACK:            ", sessionInfo()$LAPACK),
  paste0("ShrinkageTrees:    ", st_ver,
         if (st_ver != "2.0.2") "  [SPEC EXPECTS 2.0.2]" else ""),
  paste0("BART:              ", bart_ver,
         if (have_BART && bart_ver != "2.9.10") "  [SPEC EXPECTS 2.9.10]" else ""),
  "",
  paste0("Burn-in per chain:    ", N_BURN),
  paste0("Posterior per chain:  ", N_POST),
  paste0("n_chains:             ", N_CHAINS),
  paste0("Trees (m):            ", M_TREES),
  paste0("Representative n, p:  ", TABLE_N, ", ", TABLE_P),
  paste0("Scaling grid (n):     ", paste(N_GRID, collapse = ", "))
), "outputs/benchmark_meta.txt")

if (!have_BART) {
  message("Package 'BART' is not installed. The script will run the three ",
          "ShrinkageTrees fits, write a clear note in benchmark_table.csv, ",
          "and skip the BART::abart() comparison.")
}

# ── DGP: AFT log-normal with right-censoring at ~35% ────────────────────────
# log T = 2 + X1 - 0.8 X2 + 0.6 X3 - 0.4 X5 + N(0, 0.5^2)   (X4 inactive)
# C ~ Exp(rate); rate is calibrated once on a large reference draw to give
# P(C < T) ≈ 0.35.
calibrate_censoring_rate <- function(target = 0.35, n_ref = 100000L,
                                     seed = 99L) {
  set.seed(seed)
  X <- matrix(rnorm(n_ref * 5L), n_ref, 5L)
  log_T <- 2 + X[, 1] - 0.8 * X[, 2] + 0.6 * X[, 3] - 0.4 * X[, 5] +
    rnorm(n_ref, sd = 0.5)
  T_ref <- exp(log_T)
  # P(C < T) = E[1 - exp(-rate * T)]; solve for rate.
  f <- function(rate) mean(1 - exp(-rate * T_ref)) - target
  uniroot(f, lower = 1e-8, upper = 100, tol = 1e-6)$root
}

CENSOR_RATE <- calibrate_censoring_rate()

sim_data <- function(n, p, seed) {
  set.seed(seed)
  X <- matrix(rnorm(n * p), n, p)
  colnames(X) <- paste0("x", seq_len(p))
  log_T <- 2 + X[, 1] - 0.8 * X[, 2] + 0.6 * X[, 3] - 0.4 * X[, 5] +
    rnorm(n, sd = 0.5)
  T  <- exp(log_T)
  C  <- rexp(n, rate = CENSOR_RATE)
  Y  <- pmin(T, C)
  d  <- as.integer(T <= C)
  list(time = Y, status = d, X = X)
}

# ── Wall-clock timer (returns elapsed seconds) ───────────────────────────────
time_call <- function(expr) {
  t0 <- Sys.time()
  res <- tryCatch(force(expr), error = function(e) e)
  t1 <- Sys.time()
  list(seconds = as.numeric(difftime(t1, t0, units = "secs")),
       error   = if (inherits(res, "error")) conditionMessage(res) else NA)
}

# ── Fit launchers ────────────────────────────────────────────────────────────
fit_survival_bart <- function(d) {
  SurvivalBART(time = d$time, status = d$status, X_train = d$X,
               number_of_trees = M_TREES,
               N_post = N_POST, N_burn = N_BURN,
               n_chains = N_CHAINS, verbose = FALSE)
}
fit_survival_dart <- function(d) {
  SurvivalDART(time = d$time, status = d$status, X_train = d$X,
               number_of_trees = M_TREES,
               N_post = N_POST, N_burn = N_BURN,
               n_chains = N_CHAINS, verbose = FALSE)
}
fit_horse_trees <- function(d) {
  HorseTrees(y = d$time, status = d$status, X_train = d$X,
             outcome_type = "right-censored", timescale = "time",
             number_of_trees = M_TREES, k = 0.1,
             N_post = N_POST, N_burn = N_BURN,
             n_chains = N_CHAINS, verbose = FALSE)
}
# BART::mc.abart() splits a target *total* posterior count across mc.cores
# parallel chains: each child chain produces ceiling(ndpost / mc.cores)
# draws, with its own seed. To match the ShrinkageTrees fits (which run
# n_chains independent chains with N_POST draws each), we therefore pass
# ndpost = N_POST * N_CHAINS so every chain produces N_POST draws.
fit_mc_abart <- function(d, base_seed) {
  BART::mc.abart(x.train = d$X, times = d$time, delta = d$status,
                 ntree = M_TREES,
                 nskip  = N_BURN,
                 ndpost = N_POST * N_CHAINS,
                 mc.cores = N_CHAINS,
                 seed   = base_seed,
                 printevery = N_BURN + N_POST + 1L)
}

# ── Single benchmark run ────────────────────────────────────────────────────
run_one <- function(fn_name, n, p, seed, replicate) {
  d <- sim_data(n, p, seed = seed)
  cat(sprintf("  %-12s  n=%-4d  p=%-4d  rep=%d (seed=%d) ... ",
              fn_name, n, p, replicate, seed))
  flush.console()

  res <- switch(
    fn_name,
    "SurvivalBART"   = time_call(fit_survival_bart(d)),
    "SurvivalDART"   = time_call(fit_survival_dart(d)),
    "HorseTrees"     = time_call(fit_horse_trees(d)),
    "BART::mc.abart" = time_call(fit_mc_abart(d, base_seed = seed)),
    stop("Unknown fn: ", fn_name)
  )

  if (!is.na(res$error)) {
    cat(sprintf("FAILED in %.1fs: %s\n", res$seconds, res$error))
  } else {
    cat(sprintf("%7.2f s\n", res$seconds))
  }

  data.frame(
    fn          = fn_name,
    n           = n,
    p           = p,
    m           = M_TREES,
    n_chains    = N_CHAINS,
    replicate   = replicate,
    time_seconds = res$seconds,
    error       = ifelse(is.na(res$error), "", res$error),
    stringsAsFactors = FALSE
  )
}

# ── Active function set ──────────────────────────────────────────────────────
active_fns <- if (have_BART) FN_LEVELS else setdiff(FN_LEVELS, "BART::mc.abart")

# ── Table scenario: n = 500, p = 100, 5 replications ────────────────────────
cat("=== Representative scenario: n =", TABLE_N, ", p =", TABLE_P,
    ", reps =", REP_TABLE, "===\n")
table_seeds <- 1001L + seq_len(REP_TABLE)
table_rows  <- list()
for (fn in active_fns) {
  for (r in seq_len(REP_TABLE)) {
    table_rows[[length(table_rows) + 1L]] <-
      run_one(fn, TABLE_N, TABLE_P, seed = table_seeds[r], replicate = r)
  }
}

# ── Scaling scenario: vary n, 3 replications per (fn, n) ─────────────────────
cat("\n=== Scaling in n: p =", P_FIXED, ", reps per (fn, n) =", REP_SCALING,
    " ===\n")
scaling_rows <- list()
for (fn in active_fns) {
  for (n in N_GRID) {
    for (r in seq_len(REP_SCALING)) {
      seed <- 2000L + n + r
      scaling_rows[[length(scaling_rows) + 1L]] <-
        run_one(fn, n, P_FIXED, seed = seed, replicate = r)
    }
  }
}

# ── Combine & write CSV (raw long format, per spec) ──────────────────────────
all_rows <- do.call(rbind, c(table_rows, scaling_rows))
# Spec asks for a column literally called "function". Apply it at write time
# so the script can manipulate the data frame without quoting headaches.
csv_out <- all_rows
names(csv_out)[names(csv_out) == "fn"] <- "function"
write.csv(csv_out, "outputs/benchmark_table.csv",
          row.names = FALSE)

# ── Formatted text table (representative scenario) ───────────────────────────
table_df <- subset(all_rows, n == TABLE_N & p == TABLE_P & error == "")
agg <- do.call(rbind, lapply(split(table_df, table_df$fn), function(g) {
  data.frame(fn        = g$fn[1],
             reps      = nrow(g),
             mean_sec  = mean(g$time_seconds),
             sd_sec    = sd(g$time_seconds),
             stringsAsFactors = FALSE)
}))
agg <- agg[match(active_fns, agg$fn), ]
agg$display <- sprintf("%6.1f ± %4.1f", agg$mean_sec, agg$sd_sec)

sink("outputs/benchmark_table.txt")
cat(sprintf(
  "Representative scenario: n = %d, p = %d, m = %d, n_chains = %d\n",
  TABLE_N, TABLE_P, M_TREES, N_CHAINS))
cat(sprintf("Burn-in = %d, posterior draws = %d (per chain), reps = %d\n\n",
            N_BURN, N_POST, REP_TABLE))
out_tbl <- data.frame(`function` = agg$fn,
                      `time (s, mean +/- SD)` = agg$display,
                      check.names = FALSE)
print(out_tbl, row.names = FALSE)
sink()

# ── Scaling figure ──────────────────────────────────────────────────────────
sc_df <- subset(all_rows, n %in% N_GRID & p == P_FIXED & error == "")
sc_summary <- do.call(rbind, lapply(split(sc_df, list(sc_df$fn, sc_df$n),
                                          drop = TRUE), function(g) {
  data.frame(fn       = g$fn[1],
             n        = g$n[1],
             mean_sec = mean(g$time_seconds),
             sd_sec   = sd(g$time_seconds),
             stringsAsFactors = FALSE)
}))
sc_summary$fn <- factor(FN_DISPLAY[sc_summary$fn],
                        levels = FN_DISPLAY[FN_LEVELS])

p_scaling <- ggplot(sc_summary,
                    aes(x = n, y = mean_sec, colour = fn, fill = fn)) +
  geom_ribbon(aes(ymin = mean_sec - sd_sec, ymax = mean_sec + sd_sec),
              alpha = 0.18, colour = NA) +
  geom_line(linewidth = 0.6) +
  geom_point(size = 1.6) +
  scale_x_continuous(breaks = N_GRID) +
  labs(x = "Sample size",
       y = "Wall-clock seconds",
       colour = NULL, fill = NULL) +
  theme_bw(base_size = 10) +
  theme(legend.position = "bottom")

ggsave("figures/benchmark_scaling.pdf", p_scaling, width = 6, height = 3.5)

# ── Resolved placeholders summary (also echoed to stdout) ───────────────────
placeholders <- c(
  "",
  "----------------------------------------------------------------",
  "Resolved placeholder values for §6.5 of the paper",
  "----------------------------------------------------------------",
  paste0("Representative n:        ", TABLE_N),
  paste0("Representative p:        ", TABLE_P),
  paste0("Burn-in per chain:       ", N_BURN),
  paste0("Posterior draws / chain: ", N_POST),
  paste0("R version:               ", R.version.string),
  paste0("ShrinkageTrees version:  ", st_ver,
         if (st_ver == "2.0.2") "  [matches spec]" else "  [DIFFERS from spec 2.0.2]"),
  paste0("BART version:            ", bart_ver,
         if (have_BART && bart_ver == "2.9.10") "  [matches spec]"
         else if (have_BART) "  [DIFFERS from spec 2.9.10]" else ""),
  paste0("Calibrated censoring rate (Exp): ",
         signif(CENSOR_RATE, 4),
         "   target censoring fraction = 0.35"),
  ""
)
cat(paste(placeholders, collapse = "\n"))
cat(paste(placeholders, collapse = "\n"),
    file = "outputs/benchmark_meta.txt", append = TRUE)

# ── Failure report ───────────────────────────────────────────────────────────
fails <- subset(all_rows, error != "")
if (nrow(fails) > 0L) {
  cat("\n!!! FAILURES — review before using the table/figure:\n")
  print(fails[, c("fn", "n", "p", "replicate", "error")], row.names = FALSE)
} else {
  cat("All fits completed without errors.\n")
}

cat("\nFiles written:\n",
    "  outputs/benchmark_table.csv\n",
    "  outputs/benchmark_table.txt\n",
    "  outputs/benchmark_meta.txt\n",
    "  figures/benchmark_scaling.pdf\n", sep = "")
