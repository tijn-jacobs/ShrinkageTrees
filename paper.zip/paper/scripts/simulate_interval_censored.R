################################################################################
# Interval-censored simulation for the ShrinkageTrees R Journal paper.
# Mirrors simulations/simple/revision_simple_deeper3c.R, adapted to IC outcomes
# and the three wrappers SurvivalBART(), SurvivalDART(), HorseTrees().
################################################################################

library(ShrinkageTrees)
library(doParallel)
library(foreach)

# Resolve paper/ as the working directory regardless of where Rscript is
# invoked from, so outputs always land in paper/outputs/.
.script_path <- (function() {
  args <- commandArgs(trailingOnly = FALSE)
  flag <- "--file="
  m <- grep(flag, args, fixed = TRUE)
  if (length(m)) sub(flag, "", args[m], fixed = TRUE) else NULL
})()
if (!is.null(.script_path) && nzchar(.script_path)) {
  setwd(normalizePath(file.path(dirname(.script_path), "..")))
}
dir.create("outputs", showWarnings = FALSE)

# ── Data-generating process ──────────────────────────────────────────────────
# Friedman + sparse linear (spike-and-slab) on X ~ U[0,1]^p.
# beta is drawn FRESH inside each call (so every replicate sees a new active set).
# f is rescaled to unit variance via a reference draw, then sigma is set so that
# var(Y) / sigma^2 = var_ratio   ⇒   sigma^2 = 1 / (var_ratio - 1).
data_gen <- function(
    n,
    n_test,
    p,
    var_ratio = 10 / 9,
    s_slab    = 0.05,
    n_ref     = 5000L
) {
  beta         <- rep(0, p)
  active       <- rbinom(p, 1L, s_slab) == 1L
  beta[active] <- rnorm(sum(active))

  f_raw <- function(x) {
    10 * sin(pi * x[, 1] * x[, 2]) +
      20 * (x[, 3] - 0.5)^2 +
      10 * x[, 4] +
       5 * x[, 5] +
      as.vector(x %*% beta)
  }

  x_ref <- matrix(runif(n_ref * p), n_ref, p)
  sd_f  <- sd(f_raw(x_ref))
  rm(x_ref)

  f     <- function(x) f_raw(x) / sd_f
  sigma <- sqrt(1 / (var_ratio - 1))

  X_train <- matrix(runif(n      * p), n,      p)
  X_test  <- matrix(runif(n_test * p), n_test, p)
  colnames(X_train) <- colnames(X_test) <- paste0("x", seq_len(p))

  f_train <- f(X_train)
  f_test  <- f(X_test)
  log_t   <- f_train + rnorm(n, 0, sigma)

  # ── Interval-censoring (log scale) ────────────────────────────────────────
  log_t_floor <- min(log_t) - 1
  log_t_max   <- quantile(log_t, 0.95)
  v <- t(apply(matrix(runif(n * 3, log_t_floor, log_t_max), n, 3), 1, sort))

  log_left  <- numeric(n)
  log_right <- numeric(n)
  for (i in seq_len(n)) {
    li <- log_t[i]
    if (li > v[i, 3]) {
      log_left[i]  <- v[i, 3]
      log_right[i] <- Inf
    } else if (li <= v[i, 1]) {
      log_left[i]  <- log_t_floor
      log_right[i] <- v[i, 1]
    } else {
      j <- which(v[i, ] >= li)[1]
      log_left[i]  <- v[i, j - 1]
      log_right[i] <- v[i, j]
    }
  }

  list(
    X_train   = X_train,
    X_test    = X_test,
    f_train   = f_train,
    f_test    = f_test,
    log_left  = log_left,
    log_right = log_right,
    sigma     = sigma,
    n_active  = sum(active),
    n_rcens   = sum(!is.finite(log_right))
  )
}

# ── Metrics ──────────────────────────────────────────────────────────────────
compute_metrics <- function(f_hat, f_post, f_true) {
  rmse     <- sqrt(mean((f_hat - f_true)^2))
  ci_lower <- apply(f_post, 2, quantile, 0.025)
  ci_upper <- apply(f_post, 2, quantile, 0.975)
  coverage <- mean(f_true >= ci_lower & f_true <= ci_upper)
  length_  <- mean(ci_upper - ci_lower)
  c(RMSE = rmse, Coverage = coverage, Length = length_)
}

# ── Per-method fit launchers (return train + test posterior summaries) ──────
shared_args <- function(data, N_post, N_burn, n_chains, m) list(
  left_time  = data$log_left,
  right_time = data$log_right,
  timescale  = "log",
  X_train    = data$X_train,
  X_test     = data$X_test,
  number_of_trees = m,
  N_post     = N_post,
  N_burn     = N_burn,
  n_chains   = n_chains,
  store_posterior_sample = TRUE,
  verbose    = FALSE
)

fit_outputs <- function(fit) list(
  train = list(f_hat  = as.numeric(fit$train_predictions),
               f_post = fit$train_predictions_sample),
  test  = list(f_hat  = as.numeric(fit$test_predictions),
               f_post = fit$test_predictions_sample)
)

fit_bart <- function(data, N_post, N_burn, n_chains = 4, m = 200) {
  fit_outputs(do.call(SurvivalBART,
                      shared_args(data, N_post, N_burn, n_chains, m)))
}

fit_dart <- function(data, N_post, N_burn, n_chains = 4, m = 200) {
  fit_outputs(do.call(SurvivalDART,
                      shared_args(data, N_post, N_burn, n_chains, m)))
}

fit_horse <- function(data, N_post, N_burn, n_chains = 4, m = 200, k = 0.1) {
  args <- c(shared_args(data, N_post, N_burn, n_chains, m),
            list(outcome_type = "interval-censored", k = k))
  fit_outputs(do.call(HorseTrees, args))
}

# ── One replication ──────────────────────────────────────────────────────────
run_one_sim <- function(
    seed,
    n        = 100,
    n_test   = 1000,
    p        = 500,
    N_post   = 5000,
    N_burn   = 5000,
    n_chains = 4,
    m        = 200,
    k_horse  = 0.1
) {
  set.seed(seed)
  dat <- data_gen(n = n, n_test = n_test, p = p)

  fits <- list(
    BART               = fit_bart(dat,  N_post, N_burn, n_chains, m),
    DART               = fit_dart(dat,  N_post, N_burn, n_chains, m),
    `Horseshoe Forest` = fit_horse(dat, N_post, N_burn, n_chains, m, k_horse)
  )

  out <- do.call(rbind, lapply(names(fits), function(method) {
    do.call(rbind, lapply(c("train", "test"), function(split) {
      truth <- if (split == "train") dat$f_train else dat$f_test
      m_vec <- compute_metrics(fits[[method]][[split]]$f_hat,
                               fits[[method]][[split]]$f_post,
                               truth)
      data.frame(Method   = method,
                 Split    = split,
                 RMSE     = unname(m_vec["RMSE"]),
                 Coverage = unname(m_vec["Coverage"]),
                 Length   = unname(m_vec["Length"]),
                 stringsAsFactors = FALSE)
    }))
  }))

  out$n_active <- dat$n_active
  out$n_rcens  <- dat$n_rcens
  out
}

# ── Parallel runner over replications (one p) ───────────────────────────────
run_simulation_tidy <- function(
    n_rep, n, n_test, p,
    N_post, N_burn, n_chains, m, k_horse,
    seed_offset = 1000L
) {
  foreach(
    i = seq_len(n_rep),
    .combine = "rbind",
    .packages = "ShrinkageTrees"
  ) %dopar% {
    res <- run_one_sim(
      seed     = seed_offset + i,
      n        = n,
      n_test   = n_test,
      p        = p,
      N_post   = N_post,
      N_burn   = N_burn,
      n_chains = n_chains,
      m        = m,
      k_horse  = k_horse
    )
    res$Iter <- i
    res$p    <- p
    res
  }
}

# ── Main ─────────────────────────────────────────────────────────────────────
args <- commandArgs(trailingOnly = TRUE)
# num_cores <- if (length(args) > 0) {
#   as.integer(args[1]) - 1L
# } else {re
#   parallel::detectCores() - 1L
# }
num_cores <- 5
registerDoParallel(cores = num_cores)
cat("Number of cores being used (1 free):", num_cores, "\n")
cat("SIMULATION: interval-censored (Friedman + spike-and-slab)\n")

set.seed(42)

M        <- 1000L
n        <- 200L
n_test   <- 1000L
N_post   <- 5000L
N_burn   <- 5000L
n_chains <- 1
m_trees  <- 200L
k_horse  <- 0.1
p_values <- c(500L, 5000L)

all_sim_data <- list()
for (p_val in p_values) {
  cat("Running simulation for p =", p_val, "\n")
  sim_df <- run_simulation_tidy(
    n_rep    = M,
    n        = n,
    n_test   = n_test,
    p        = p_val,
    N_post   = N_post,
    N_burn   = N_burn,
    n_chains = n_chains,
    m        = m_trees,
    k_horse  = k_horse
  )
  all_sim_data[[as.character(p_val)]] <- sim_df
}

final_flat_df <- do.call(rbind, all_sim_data)

output_file <- "outputs/simulate_interval_censored_output.rds"
cat("Saving all settings results to:", output_file, "\n")
saveRDS(final_flat_df, file = output_file)
cat("All results successfully saved in one file.\n")
