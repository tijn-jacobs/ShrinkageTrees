# ShrinkageTrees — R Journal paper

All `{r}` chunks in `ShrinkageTrees.Rmd` are `eval = FALSE`. Every figure,
table, and numeric value is precomputed and inlined from `outputs/` and
`figures/`, both of which are included in this repository. To knit the
paper directly, no scripts need to be run:

```r
rmarkdown::render("paper/ShrinkageTrees.Rmd")
```

To reproduce the precomputed artefacts from scratch, run the scripts in
`scripts/` in this order before knitting:

```sh
cd paper
Rscript scripts/generate_figures.R            # §2–4: worked example  (~minutes)
Rscript scripts/simulate_interval_censored.R  # §5: simulation        (~hours)
Rscript scripts/benchmarks.R                  # §6.5: benchmarks      (~1–2h)
```

Required packages (CRAN only):

```r
install.packages(c("ShrinkageTrees", "BART", "coda", "doParallel",
                   "foreach", "ggplot2", "survival"))
```
