#ifndef HORSETREES_H
#define HORSETREES_H

#include "Forest.h"
#include "TruncatedNormal.h"
#include "OuterGibbsFunctions.h"




#endif // HORSETREES_H
