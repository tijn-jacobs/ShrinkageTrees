#ifndef TruncatedNormal_h
#define TruncatedNormal_h

#include "Prerequisites.h"

double rtnorm(double mean, double truncation, double sd, Random& random);

#endif
