#ifndef CAUSAL_HORSETREES_H
 #define CAUSAL_HORSETREES_H
 
 #include "HorseTrees.h"
 #include "probit-HorseTrees.h"
 #include "OuterGibbsFunctions.h"

 
 #endif // CAUSAL_HORSETREES_H
 
